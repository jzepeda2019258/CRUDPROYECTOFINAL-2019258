DROP DATABASE IF EXISTS DBRegistro;
CREATE DATABASE DBRegistro;

USE DBRegistro;

CREATE TABLE Persona(
	codigoPersona INT NOT NULL AUTO_INCREMENT,
	DPI VARCHAR(15)NOT NULL,
	nombrePersona VARCHAR(200)NOT NULL,
	PRIMARY KEY PK_codigoPersona (codigoPersona)

);

INSERT INTO Persona(DPI,nombrePersona) VALUES ('156789432','Luis Velasquez');
INSERT INTO Persona(DPI,nombrePersona) VALUES ('875469084','Jorge Veliz');
INSERT INTO Persona(DPI,nombrePersona) VALUES ('174390283','Jose Jax');
INSERT INTO Persona(DPI,nombrePersona) VALUES ('109238754','Jonathan Zepeda');
INSERT INTO Persona(DPI,nombrePersona) VALUES ('983087263','Edy Teleguario');
INSERT INTO Persona(DPI,nombrePersona) VALUES ('483792034','Carlos Vicente');

SELECT *FROM Persona;